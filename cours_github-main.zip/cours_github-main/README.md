# Cours GitHub Ada

Premier fichier ajouté à Git.

Deuxième commit du cours pour apprendre la commande `git pull`.

Premier commit dans la branche `premiere_branche`

Apprendre à faire une pull request

Modification pour le rebase
Modification pour le rebase numero 2

Commit squash 1
Commit squash 2
Commit squash 3

1er commit dans la branche pycharm